document.addEventListener("DOMContentLoaded", () => {
  const board = document.getElementById("chessboard");
  const turnDisplay = document.getElementById("turn");
  let currentTurn = "white"; // ✅ White starts

  const piecesLayout = [
    ["r", "n", "b", "q", "k", "b", "n", "r"],
    ["p", "p", "p", "p", "p", "p", "p", "p"],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["", "", "", "", "", "", "", ""],
    ["P", "P", "P", "P", "P", "P", "P", "P"],
    ["R", "N", "B", "Q", "K", "B", "N", "R"],
  ];

  const symbols = {
    K: "♔", Q: "♕", R: "♖", B: "♗", N: "♘", P: "♙", // White
    k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟", // Black
  };

  function getColor(pieceType) {
    return pieceType === pieceType.toUpperCase() ? "white" : "black";
  }

  // ✅ Check if move is valid
  function isValidMove(pieceType, fromRow, fromCol, toRow, toCol, targetSquare) {
    const color = getColor(pieceType);

    // Pawn rules
    if (pieceType.toUpperCase() === "P") {
      const direction = color === "white" ? -1 : 1; // white moves up, black down
      const startRow = color === "white" ? 6 : 1;

      // Normal move: forward 1 if empty
      if (fromCol === toCol && toRow === fromRow + direction && !targetSquare.firstChild) {
        return true;
      }

      // First move: forward 2 if empty
      if (
        fromCol === toCol &&
        fromRow === startRow &&
        toRow === fromRow + 2 * direction &&
        !targetSquare.firstChild
      ) {
        return true;
      }

      // Capture: diagonal 1 if enemy present
      if (
        Math.abs(toCol - fromCol) === 1 &&
        toRow === fromRow + direction &&
        targetSquare.firstChild &&
        targetSquare.firstChild.dataset.color !== color
      ) {
        return true;
      }

      return false;
    }

    // Rook rules
    if (pieceType.toUpperCase() === "R") {
      if (fromRow !== toRow && fromCol !== toCol) return false; // must be straight

      // Check path is clear
      if (fromRow === toRow) {
        const step = fromCol < toCol ? 1 : -1;
        for (let c = fromCol + step; c !== toCol; c += step) {
          const square = document.querySelector(`[data-row="${fromRow}"][data-col="${c}"]`);
          if (square.firstChild) return false;
        }
      } else {
        const step = fromRow < toRow ? 1 : -1;
        for (let r = fromRow + step; r !== toRow; r += step) {
          const square = document.querySelector(`[data-row="${r}"][data-col="${fromCol}"]`);
          if (square.firstChild) return false;
        }
      }

      // Can move if target is empty or enemy
      if (!targetSquare.firstChild || targetSquare.firstChild.dataset.color !== color) {
        return true;
      }
      return false;
    }

    return true; // other pieces (no rules yet)
  }

  // Build board
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const square = document.createElement("div");
      square.classList.add("square");
      square.classList.add((row + col) % 2 === 0 ? "light" : "dark");
      square.dataset.row = row;
      square.dataset.col = col;

      const pieceType = piecesLayout[row][col];
      if (pieceType) {
        const piece = document.createElement("div");
        piece.classList.add("piece");
        piece.textContent = symbols[pieceType];
        piece.id = pieceType + "-" + row + col;
        piece.dataset.color = getColor(pieceType);
        piece.dataset.type = pieceType;
        piece.setAttribute("draggable", "true");

        piece.addEventListener("dragstart", (e) => {
          if (piece.dataset.color !== currentTurn) {
            e.preventDefault(); // wrong turn
            return;
          }
          e.dataTransfer.setData("pieceId", piece.id);
          e.dataTransfer.setData("fromRow", square.dataset.row);
          e.dataTransfer.setData("fromCol", square.dataset.col);
        });

        square.appendChild(piece);
      }

      // Allow dropping
      square.addEventListener("dragover", (e) => e.preventDefault());
      square.addEventListener("drop", (e) => {
        e.preventDefault();
        const pieceId = e.dataTransfer.getData("pieceId");
        if (!pieceId) return;

        const piece = document.getElementById(pieceId);
        const fromRow = parseInt(e.dataTransfer.getData("fromRow"));
        const fromCol = parseInt(e.dataTransfer.getData("fromCol"));
        const toRow = parseInt(square.dataset.row);
        const toCol = parseInt(square.dataset.col);

        // ✅ Check move legality
        if (!isValidMove(piece.dataset.type, fromRow, fromCol, toRow, toCol, square)) {
          return; // ❌ illegal move
        }

        // Capture if enemy
        if (square.firstChild) {
          square.removeChild(square.firstChild);
        }

        square.appendChild(piece);

        // ✅ Switch turn
        currentTurn = currentTurn === "white" ? "black" : "white";
        turnDisplay.textContent =
          "Turn: " + currentTurn.charAt(0).toUpperCase() + currentTurn.slice(1);
      });

      board.appendChild(square);
    }
  }
});
